// import './App.css';
import './components/FunctionPointCalculator';
import FunctionPointCalculator from './components/FunctionPointCalculator';
function App() {
  return (
    <div className="App">
      <header className="App-header">
        
      </header>
      <FunctionPointCalculator/>
    </div>
  );
}

export default App;
